/**
 * TODO 1: Erstellen Sie ein on-Click-Event für den change-me Button.
 * TODO 2: Dabei soll der Text des Buttons zu "Changed" geändert werden.
 * TODO 3: Lassen Sie in die Konsole ausgeben, dass der Text geändert wurde.
 */

// Nach dieser Zeile den Code für den change-me-Button beginnen.

/**
 * TODO 3: Erstellen Sie ein on-Click-Event für den style-me Button.
 * TODO 4: Dabei soll der Button die Klasse "styled" erhalten, falls er diese noch nicht hat.
 * TODO 5: Hat er die Klasse bereits, soll sie entfernt werden.
 * TODO 6: Lassen Sie in die Konsole ausgeben, dass die Klasse hinzugefügt bzw. entfernt wurde.
 */

// Nach dieser Zeile den Code für den style-me-Button beginnen.
